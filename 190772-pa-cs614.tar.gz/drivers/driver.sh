sudo rmmod -f cryptocard_mod;
make clean && make && sudo insmod cryptocard_mod.ko && make clean
